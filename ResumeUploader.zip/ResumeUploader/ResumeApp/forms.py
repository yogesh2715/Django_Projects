from django import forms
from.models import ResumeModel

gender_choice=[('Male','Male'),('Female','Female'),('Not to Prefered','Not to Prefered')]

lang_choice=[('Marathi','Marathi'),('English','English'),('Hindi','Hindi'),('Gujarati','Gujarati'),('Tamil','Tamil')]

lang_skills_choice=[('Python','Python'),('SQL','SQL'),('JavaScript','JavaScript'),('HTML','HTML'),('CSS','CSS'),('PHP','PHP'),('C++','C++'),('JAVA','JAVA'),('Ruby','Ruby'),('Swift','Swift')]

prefered_loc_choice=[('Mumbai','Mumabi'),('Pune','Pune'),('Nashik','Nashik'),('Banglore','Banglore'),('Delhi','Delhi')]

class ResumeForm(forms.ModelForm):
    gender=forms.ChoiceField(label='Select Genter',choices=gender_choice,widget=forms.RadioSelect)
    
    lang=forms.MultipleChoiceField(label='Select Language',choices=lang_choice,widget=forms.CheckboxSelectMultiple())

    lang_skills=forms.MultipleChoiceField(label='Select Languages Skill ',choices=lang_skills_choice,widget=forms.CheckboxSelectMultiple())

    prefered_loc=forms.ChoiceField(label='Select Prefered location ',choices=prefered_loc_choice,widget=forms.RadioSelect)


    
    class Meta:
        model=ResumeModel

        fields=['fname','lname','email','contact','gender','dob','city','state','pin','lang','lang_skills','prefered_loc','qual','profile_image','projects']

        
        labels={
            'fname':'Enter Your First Name',
            'lname':'Enter Your Last Name',
            'email':'Enter Your Email',
            'contact':'Enter Your Contact',
            'gender':'Select Your Gender',
            'dob':'Enter Your Date Of Birth',
            'city':'Select City',
            'state':'Select State',
            'pin':'Enter Pin Code',
            'lang':'Select Language',
            'lang_skills':'Select Language Skills',
            'prefered_loc':'Select Prefered Location',
            'qual':'Enter Qualification',
            'profile_image':'Upload Profile Picture',
            'projects':'Enter Your Project Details',
        }

        widgets={
            'fname':forms.TextInput(attrs={'class':'form-control'}),
            'lname':forms.TextInput(attrs={'class':'form-control'}),
            'email':forms.EmailInput(attrs={'class':'form-control'}),
            'contact':forms.TextInput(attrs={'class':'form-control'}),
            'city':forms.Select(attrs={'class':'form-control w-30'}),
            'state':forms.Select(attrs={'class':'form-control w-30'}),
            'pin':forms.NumberInput(attrs={'class':'form-control '}),
            'prefered_loc':forms.Select(attrs={'class':'form-control w-30'}),
            'qual':forms.TextInput(attrs={'class':'form-control'}),

            'project':forms.TextInput(attrs={'class':'form-control'})

            }