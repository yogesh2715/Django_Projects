from django.db import models

# Create your models here.

gender_choice=[('Male','Male'),('Female','Female'),('Not to Prefered','Not to Prefered')]
city_choice=[('Thane','Thane'),('Mumbai','Mumbai'),('Nashik','Nashik'),('Hydrabad','Hydrabad'),('Chennai','Chennai'),('Banglore','Banglore'),('Jaipur','Jaipur'),('Chandigarh','Chandigarh'),('Ahmedabad','Ahmedabad')]
state_choice=[('Maharashtra','Maharashtra'),('Goa','Goa'),('Andhra Pradesh','Andhra Pradesh'),('Arunachal Pradesh','Arunachal Pradesh'),('Assam','Assam'),('Bihar','Bihar'),('Chhattisgarh','Chhattisgarh'),('Gujarat','Gujarat'),('Rajasthan','Rajasthan'),('Tamilnadu','Tamilnadu')]
lang_choice=[('Marathi','Marathi'),('English','English'),('Hindi','Hindi'),('Gujarati','Gujarati'),('Tamil','Tamil')]
lang_skills_choice=[('Python','Python'),('SQL','SQL'),('JavaScript','JavaScript'),('HTML','HTML'),('CSS','CSS'),('PHP','PHP'),('C++','C++'),('JAVA','JAVA'),('Ruby','Ruby'),('Swift','Swift')]
prefered_loc_choice=[('Mumbai','Mumabi'),('Pune','Pune'),('Nashik','Nashik'),('Banglore','Banglore'),('Delhi','Delhi')]

class ResumeModel(models.Model):
    fname=models.CharField(max_length=100)
    lname=models.CharField(max_length=100)
    email=models.EmailField()
    contact=models.CharField(max_length=100)
    gender=models.CharField(max_length=100)
    dob=models.DateField(auto_now=False,auto_now_add=False)
    city=models.CharField(choices=city_choice, max_length=100)
    state=models.CharField(choices=state_choice, max_length=100)
    pin=models.PositiveIntegerField()
    lang=models.CharField(max_length=100)
    lang_skills=models.CharField(max_length=100)
    prefered_loc=models.CharField(max_length=100)
    qual=models.CharField(max_length=100)
    profile_image=models.ImageField(upload_to="Profile_Image/",blank=True)
    projects=models.TextField()